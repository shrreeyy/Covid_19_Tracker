# covid19_tracker_demo

A Covid-19 Tracker built using Flutter. It shows stats of Indian states and Global countries. There is also a news section which shows Indian & Global news related to health & care.

## Screenshots

<img src="screenshot/Screenshot1.png" width=280px height=450px>
<img src="screenshot/Screenshot2.png" width=280px height=450px>
<img src="screenshot/Screenshot3.png" width=280px height=450px>
<img src="screenshot/Screenshot4.png" width=280px height=450px>
<img src="screenshot/Screenshot5.png" width=280px height=450px>
